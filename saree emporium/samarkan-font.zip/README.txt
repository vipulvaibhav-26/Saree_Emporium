This font is shareware. A great deal of time and effort has gone into its creation. It has been carefully crafted to contain the minimum number of points necessary to render each character accurately and efficiently. If you intend to use it, please register by sending $7.50 in US funds by PayPal to ethelrp@gmail.com, or by check or money order to:

	Ethel Enterprises
	5284 Harshaw Road
	Murphy, NC 28906-8008

Please do not send checks or money orders in non-US funds as the conversion fee is more than the payment.

This font is copyright 1993, 1995 by Titivillus Foundry. No warranty is either expressed or implied for its use. It has been thoroughly tested, and shown to perform as it should. It may be freely distributed on BBSs, CDs, disks, or whatever, provided that it is in no way altered, and this readme file is included. Titivillus Foundry and Ethel Enterprises assume no responsibility for any changes made to our design as originally posted on Dafont or whatever site.

We hope you find it useful.

Titivillus, et al.
ethelrp@gmail.com
